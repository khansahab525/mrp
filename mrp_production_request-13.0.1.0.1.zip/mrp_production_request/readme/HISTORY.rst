12.0.1.0.0 (2019-09-13)
~~~~~~~~~~~~~~~~~~~~~~~

* [MIG] Migration to v12.

11.0.1.0.0 (2018-09-13)
~~~~~~~~~~~~~~~~~~~~~~~

* [MIG] Migration to v11. Start of the history.
